<?php
jimport('joomla.application.component.controller');

class MPollController extends JControllerLegacy
{
	function display($cachable = false, $urlparams = false)
	{
		parent::display($cachable,$urlparams);
	}

}
?>
